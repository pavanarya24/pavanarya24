# Video files go here

Drop an `.mp4` file with the exact name below next to each lesson, and it appears
automatically inside that lesson on the site — no code changes needed. A lesson
with no matching file simply shows no video block; nothing breaks.

| Filename | Lesson |
|---|---|
| lesson-01.mp4 | 1. Bid, ask, and the cost of impatience |
| lesson-02.mp4 | 2. Tape colour: finding the aggressor |
| lesson-03.mp4 | 3. Size and imbalance on the ladder |
| lesson-04.mp4 | 4. How a real breakout triggers |
| lesson-05.mp4 | 5. Absorption: someone big is quietly taking it |
| lesson-06.mp4 | 6. Telling a real wall from a spoof |
| lesson-07.mp4 | 7. Context filters |
| lesson-08.mp4 | 8. Risk and account rules |
| lesson-09.mp4 | 9. Auction theory: value area, point of control, initiative and response |
| lesson-10.mp4 | 10. Effort versus result: springs, upthrusts and the Wyckoff frame |
| lesson-11.mp4 | 11. Why liquidity gets run: dealers, adverse selection, and the plumbing under stop hunts |
| lesson-12.mp4 | 12. Process over outcome |
| lesson-13.mp4 | 13. One market, five vocabularies |
| lesson-14.mp4 | 14. Order flow imbalance and the price impact model |
| lesson-15.mp4 | 15. The statistics of your own edge |
| lesson-16.mp4 | 16. Sizing with Kelly, and why nobody trades full Kelly |
| lesson-17.mp4 | 17. Footprint charts, delta, and the four kinds of divergence |
| lesson-18.mp4 | 18. Order types, who's actually on the tape, and where this works at all |

## Notes

- **Format**: .mp4 (H.264) plays everywhere without conversion. If NotebookLM (or
  whatever tool you use) exports .webm or .mov, rename the extension only if the
  codec is actually compatible — if the video doesn't play, it needs a real
  re-encode, not just a renamed extension. `ffmpeg -i input.mov lesson-05.mp4` is
  the one-line fix if you have ffmpeg available.
- **Size**: GitHub has a 100MB per-file limit on a normal push (large files need
  Git LFS). A trimmed, focused 3–6 minute lesson video at reasonable bitrate is
  usually well under that on its own.
- **One long video instead of 18 short ones?** Rename it to `lesson-01.mp4` and
  it will show up on Lesson 1 only — the current build expects one file per
  lesson. Say the word if you'd rather have a single "course overview" video
  that appears on the Home tab instead, and I'll wire that up as a separate slot.
- If you hand video files to Claude directly instead of placing them here
  yourself, Claude can rename/trim/organize them and drop them into the right
  slot for you.
